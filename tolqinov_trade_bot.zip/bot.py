import telebot

# Bu yerda sening tokening
TOKEN = "7956958180:AAFK2MH4ep3-CoLmYK7LvXx_1WZQ39aeSS8"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Salom! 👋 Bu sening To‘lqinov Trade boting!")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, f"Sening xabaring: {message.text}")

print("Bot ishga tushdi...")
bot.polling()
