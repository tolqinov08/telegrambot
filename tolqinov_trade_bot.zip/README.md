# To‘lqinov Trade Bot 🤖

Bu bot Telegram orqali signal yoki xabar yuboradi.

## Ishga tushirish
1. Python o‘rnatilgan bo‘lishi kerak (3.9+ tavsiya).
2. Kutubxonalarni o‘rnat:
   ```bash
   pip install -r requirements.txt
   ```
3. Botni ishga tushir:
   ```bash
   python bot.py
   ```

## Xususiyatlar
- /start komandasi bilan salomlashadi.
- Yozgan har qanday xabaringni qaytarib yuboradi.
